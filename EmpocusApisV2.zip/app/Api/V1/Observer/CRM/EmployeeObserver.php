<?php

namespace App\Api\V1\Observer\CRM;

use App\Models\Master\Employee;
use Illuminate\Support\Facades\Auth;

class EmployeeObserver
{
    public function creating(Employee $employee)
    {
//        $employee->created_by = Auth::user()->id;
//        $employee->updated_by = Auth::user()->id;
    }
    /**
     * Handle the employee "created" event.
     *
     * @param  \App\Models\Master\Employee  $employee
     * @return void
     */
    public function created(Employee $employee)
    { }

    /**
     * Handle the employee "updated" event.
     *
     * @param  \App\Models\Master\Employee  $employee
     * @return void
     */
    public function updated(Employee $employee)
    {
        $employee->updated_by = Auth::user()->id;
    }

    /**
     * Handle the employee "deleted" event.
     *
     * @param  \App\Models\Master\Employee  $employee
     * @return void
     */
    public function deleted(Employee $employee)
    {
        //
    }

    /**
     * Handle the employee "restored" event.
     *
     * @param  \App\Models\Master\Employee  $employee
     * @return void
     */
    public function restored(Employee $employee)
    {
        //
    }

    /**
     * Handle the employee "force deleted" event.
     *
     * @param  \App\Models\Master\Employee  $employee
     * @return void
     */
    public function forceDeleted(Employee $employee)
    {
        //
    }
}
